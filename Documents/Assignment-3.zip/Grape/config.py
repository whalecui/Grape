#-*-coding:utf-8-*-
# import os

# ARTICLE_TITLE_DEST = os.path.join(os.path.dirname(__file__), 'upload/title_image')



##############################
# runserver.py
HOST='127.0.0.1'
PORT = 8000

db_config={
    "db_host":'127.0.0.1',
    "db_user":'root',
    "db_passwd":'1234',
    "db_port":3306,
    'db_name':'Grape'
}