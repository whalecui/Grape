Foreword:
This is a temporaroy version with all the avaliable functions work well.
Some bugs and notes:
The system will not work as we expected when Chinese characters are inputed. We are trying hard to fix it now.

Initialization of our software:
1. The software is base on Python, with flask.py, plotly and mysql used.
   Use easy_install or pip to install flask, and plotly, or you can download it by hand.
2. Run mysql on cmd or gui. Import or copy code in init.sql.
Then you can run software on your computer successfully!

Several Notes:
1. Admin account:    admin@123.com, password: admin
2. Pre-test account: myn@123.com,   password: myn
		     123@123.com,   password: 123

Have a nice day.
  